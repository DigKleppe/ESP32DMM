/*
 * Udp.h
 *
 *  Created on: May 16, 2021
 *      Author: dig
 */

#ifndef MAIN_UDP_H_
#define MAIN_UDP_H

int udpSend( char * mssg, int port) ;  // sends broadcast to port
#endif
