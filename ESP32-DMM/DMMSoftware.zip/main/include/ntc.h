#ifndef NTCH
	#define NTCH
	float readTemp(uint32_t adcVal);
	
#endif	
