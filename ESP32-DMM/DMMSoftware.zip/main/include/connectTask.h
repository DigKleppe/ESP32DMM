/*
 * coonnectTask.h
 *
 *  Created on: Jan 16, 2021
 *      Author: dig
 */

#ifndef MAIN_INCLUDE_CONNECTTASK_H_
#define MAIN_INCLUDE_CONNECTTASK_H_

void connectTask(void *pvParameters);

void initialise_wifi(void);

#endif /* MAIN_INCLUDE_CONNECTTASK_H_ */
