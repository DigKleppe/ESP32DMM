/**
 * 
 */

var data2 = 0;// =  new google.visualization.DataTable();
var chartRdy = false;
var tick = 0;
var dontDraw = false;
var halt = false;
var chartHeigth = 500;
var simValue1 = 0;
var simValue2 = 0;
var table;


const varsEnum = { "NRPoints": 0, "max": 1, "min": 2, "averages": 3, "averagesCB": 4 };


var vars = [
	{ "name": "nrPoints:", "value": 100 },
	{ "name": "max:" },
	{ "name": "min:" },
	{ "name": "averages:", "value": 15 },
	{ "name": "averagesCB:", "value": "false" },
];

const tableItems = [

	{ "element": "button", "name": "halt", "function": function() { halt = !halt } },
	{ "element": "button", "name": "clear", "function": function() { clear() } },
	{ "element": "input", "type": "checkbox", "name": "show average", "var": vars[varsEnum.averagesCB].value, "function": function() { averageCBChange(this) } },
	{ "element": "text", "name": "" },
	{ "element": "text", "name": vars[varsEnum.NRPoints].name },
	{ "element": "input", "type": "number", "var": vars[varsEnum.NRPoints], "function": function() { setPoints(this) } },
	{ "element": "text", "name": vars[varsEnum.max].name }, 
	{ "element": "input", "type": "number", "var": vars[varsEnum.max] ,"function": function() { setMax(this) } },
	{ "element": "text", "name": vars[varsEnum.min].name },
	{ "element": "input", "type": "number", "var": vars[varsEnum.min] ,"function": function() { setMin(this) } },
	{ "element": "text", "name": vars[varsEnum.averages].name },
	{ "element": "input", "type": "number", "var": vars[varsEnum.averages], function() { setAvgs(this) } },
	
];
const tableCollWidths = ['100px', '100px', '100px', '50px'];

var options = {
	title: '',
	curveType: 'function',
	legend: { position: 'bottom' },
	heigth: 200,
	crosshair: { trigger: 'both' },	// Display crosshairs on focus and selection.
	explorer: {
		actions: ['dragToZoom', 'rightClickToReset'],
		//actions: ['dragToPan', 'rightClickToReset'],
		axis: 'horizontal',
		keepInBounds: true,
		maxZoomIn: 100.0
	},
	chartArea: { 'width': '80%', 'height': '75%' },
	
    vAxis : {
        viewWindow: {
            max: vars[varsEnum.max],
			min: vars[varsEnum.min]
        }
    }
};




function clear() {
	data2.removeRows(0, data2.getNumberOfRows());
	chart.draw(data2, options);
	tick = 0;
}
function setAvgs(input) {
	vars[varsEnum.averages].value = input.value;
}

function averageCBChange(checkbox) {
	vars[varsEnum.averagesCB].value = checkbox.checked;
	if (checkbox.checked) {
		data2.addColumn('number', 'Avg');
	}
	else
		data2.removeColumn(2);

}
//the array
function initPage() {


	table = document.getElementById("settingstable"); //document.createElement("table");

	var nrRows = tableItems.length / tableCollWidths.length;
	var nrColls = tableCollWidths.length;
	for (var i = 0; i < nrRows; i++) {
		var row = table.insertRow(i);
		for (var x = 0; x < nrColls; x++) {
			var cell = row.insertCell(x);
			cell.width = tableCollWidths[x];
			var item = document.createElement(tableItems[x + i * nrColls].element);
			var t = document.createTextNode(tableItems[x + i * nrColls].name);
			item.appendChild(t);
			cell.appendChild(item);
			if (tableItems[x + i * nrColls].element == "input") {
				item.type = tableItems[x + i * nrColls].type;
				if (tableItems[x + i * nrColls].type == "checkbox") {
					item.id = "id";
					var label = document.createElement(label);
					label.htmlFor = "id";
					label.appendChild(document.createTextNode(tableItems[x + i * nrColls].name));

					cell.appendChild(label);
				}
				else {
					item.value = tableItems[x + i * nrColls].var.value;
					item.appendChild(t);
				}
				item.size = 6;// tableCollWidths[x];
				item.onchange = tableItems[x + i * nrColls].function;
			}
			else {
				item.width = tableCollWidths[x];
				item.onclick = tableItems[x + i * nrColls].function;
			}
			cell.appendChild(item);

			//		cell.style.backgroundColor = 'blue';
		}

	}
	document.body.appendChild(table);
}


function simplot( ){
	simValue1 += 0.001;
	simValue2 = Math.sin( simValue1) * 0.0001;

	plot ( simValue2);
	
	
}
function test() {
	var td = table.rows[0].cells[1];
	td.width = '150pxx';
	td.style.backgroundColor = 'blue';

}
function plot(value) {

	if (value.length > 0 ){
	document.getElementById("voltDisplay").innerHTML = value;
	value = parseFloat(value); // from string to float
	if (chartRdy) {
		if (data2.getNumberOfColumns() == 3) {
			data2.addRow([tick, value, 0]);
			var avg = average();
			data2.setValue(data2.getNumberOfRows() - 1, 2, avg);
			document.getElementById("avgDisplay").innerHTML = avg.toString();
		}
		else {
			data2.addRow([tick, value]);
			document.getElementById("avgDisplay").innerHTML = '--';
		}
		if (data2.getNumberOfRows() > vars[varsEnum.averages].value == true)
			data2.removeRows(0, data2.getNumberOfRows() - vars[varsEnum.NRPoints].value);
		tick++;
		if (!dontDraw)
			chart.draw(data2, options);
	}
	}
}

function average() {
	var sum = 0;
	var max = -9999;
	var min = 9999;
	var nrPoints = data2.getNumberOfRows();
	var nrAvgs = vars[varsEnum.averages].value;
	var val = 0;
	if (nrPoints < nrAvgs)
		nrAvgs = nrPoints;
	for (var n = 0; n < nrAvgs; n++) {
		val = data2.getValue(nrPoints - n - 1, 1);
		sum += val;
		if (val > max)
			max = val;
		if (val < min)
			min = val;
	}
	if (nrAvgs > 2) {
		sum -= max;
		sum -= min;
		return sum / (nrAvgs - 2);
	}
	else
		return sum / (nrAvgs);
}


function setPoints(input) {
	vars[varsEnum.NRPoints].value = input.value;
}


function setAvgs(input) {
	vars[varsEnum.averages].value = input.value;
}

function setMin(input) {
	vars[varsEnum.min].value = input.value;
	options.vAxis.viewWindow.min = input.value
	
}
function setMax(input) {
	vars[varsEnum.max].value = input.value;
	options.vAxis.viewWindow.max = input.value;
}

function initChart() {
	initPage();
	chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
	data2 = new google.visualization.DataTable();
	data2.addColumn('number', 'Time');
	data2.addColumn('number', 'V');
	if (vars[varsEnum.averagesCB].value == 'true')
		data2.addColumn('number', 'Avg');
	chartRdy = true;
	dontDraw = true;
	if (SIMULATE) {
		for (var z = 0; z < 100; z++) {
			simValue1 += 0.1; 1
			simValue2 = Math.sin(simValue1);
			plot(simValue2);
		}
		chart.draw(data2, options);
	}
	dontDraw = false;
	startTimer();
}

function startTimer() {
	setInterval(function() { timer() }, 500);
}

function timer() {
	var arr
	if (SIMULATE) {
		arr = simplot();
		plot(arr);
	}
	else {
		arr = getAllmeasValues();
		dontDraw = true; 
		for (var n = 0; n < arr.length; n++)
			plot(arr[n]);
		if ( !halt)
			chart.draw(data2, options);
	}
}


function chartClick() {
	if (chartHeigth = 100)
		chartHeigth = 500;
	else
		chartHeight = 100;
}


function dontDrawClick() {
	dontDraw = !dontDraw;
}





