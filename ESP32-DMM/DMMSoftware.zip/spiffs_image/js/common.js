var data2 = 0;
var simValue1 = 0;
var simValue2 = 0;

var SIMULATE = false;


function start() {
	if (SIMULATE) {
		for (var z = 0; z < 100; z++) {
			simValue1 += 0.1;
			simValue2 = Math.sin(simValue1);
			plot(simValue2);
		}
	//	setInterval(simplot, 1000);
	}
}


function simplot() {
	simValue1 += 0.1; 1
	simValue2 = Math.sin(simValue1);
	
	return simValue2;
}

// returns array with momentarty and averaged values
function getMeasValues() {
	var str;
	var req = new XMLHttpRequest();
	req.open("GET", "cgi-bin/Readvar?measValues", false);
	req.send();
	if (req.readyState == 4) {
		if (req.status == 200) {
			str = req.responseText.toString();
			var arr = str.split(",");
			return arr;
		}
	}
}
// returns array with accumulated momentary values
 function getAllmeasValues() {
	var str;
	var req = new XMLHttpRequest();
	req.open("GET", "cgi-bin/ReadAllMeasValues", false);
	req.send();
	if (req.readyState == 4) {
		if (req.status == 200) {
			str = req.responseText.toString();
			var arr = str.split(",");
			return arr;
		}
	}
}
