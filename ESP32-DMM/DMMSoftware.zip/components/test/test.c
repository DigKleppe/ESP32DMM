/*
 * test.c
 *
 *  Created on: Sep 9, 2019
 *      Author: dig
 */


#include "sntp.h"


int test ( int xx){
	xx = test(xx);
	xx+=100;
	return xx;
}
