/*
 * test.h
 *
 *  Created on: Sep 9, 2019
 *      Author: dig
 */

#ifndef COMPONENTS_TEST_INCLUDE_TEST_H_
#define COMPONENTS_TEST_INCLUDE_TEST_H_


extern "C" int test( int);


#endif /* COMPONENTS_TEST_INCLUDE_TEST_H_ */
